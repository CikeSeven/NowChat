
version = "1.26.2"
__version__ = version
full_version = version

git_revision = "9ac93b26a92b25f77a594a7a5bca6db9150ddf48"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
